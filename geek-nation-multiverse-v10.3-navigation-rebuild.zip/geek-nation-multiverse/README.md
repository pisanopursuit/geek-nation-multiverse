# Geek Nation Multiverse

The public Geek Nation Multiverse platform and its first installable authentication framework.

## Included
- Installer configured for the Geek Nation Multiverse IONOS database
- Public registration with email verification
- Login using either username or email
- SMTP through IONOS on port 587 using STARTTLS
- Password reset
- CSRF protection, prepared statements, secure password hashing, session regeneration, and login throttling
- Administrator approval for company and brand management access
- Existing static homepage retained

## Install
1. Upload all files to the document root for `geeknationmultiverse.com`.
2. Visit `https://geeknationmultiverse.com/install.php`.
3. Enter the database password, administrator password, and SMTP mailbox password.
4. Delete or rename `install.php` after confirming installation. The installer also creates `config/installed.lock`.

Do not commit `config/config.php` or `config/installed.lock`.

## Authors / Created By
Marc Delsoin, Abdoul Ba, Trevor Rukwava, & Sean Pisano

## User Identity Update

This build adds the complete User Identity MVP:

- Multi-step onboarding
- Public, member-only, and private profiles
- Avatar and banner uploads
- Identity types, interests, and favorite universes
- Profile completion tracking
- Profile editing and social links
- Notification preferences
- Administrator management for identity options

### Updating an Existing Installation

1. Upload the updated files over the existing application.
2. Keep your existing `config/config.php` and `config/installed.lock` files.
3. Sign in as the administrator.
4. Open `/upgrade.php` and click **Run Upgrade**.
5. Complete the onboarding flow.

The upgrade is additive and does not remove existing users or authentication data.

### New Installation

Run `/install.php`. The main schema now includes all User Identity tables and starter options.

### Upload Permissions

The following folders must be writable by PHP:

- `uploads/avatars/`
- `uploads/banners/`

Images are restricted to JPG, PNG, WEBP, and GIF files with a maximum size of 5 MB. Executable files are blocked in the upload directory.

## User and Administrator Invitations

After uploading the updated files, visit `/upgrade.php` as an administrator and run the upgrade. Then open `/admin/invitations.php`.

Administrators can invite either:
- **Normal User / Member** — creates an active `fan` account.
- **Administrator** — creates an active `admin` account with full administration access.

Invitation links are single-use, stored as SHA-256 hashes, and expire after seven days. Accepting an invitation verifies the invited email and routes the new account into User Identity onboarding.


## Companies module

After uploading this version to an existing installation, sign in as an administrator and visit `upgrade-companies.php`. The safe upgrade adds company profiles, declared member positions, fan submissions, membership roles, and the company approval queue.

Workflow:
1. Any active, email-verified member can submit a company.
2. The submitter declares an official relationship and position, or identifies as a fan.
3. An administrator reviews the submission in `admin/companies.php`.
4. On approval, an officially affiliated submitter becomes Company Owner. A fan submitter remains a fan and receives no ownership permissions.
5. Approved companies receive public profiles and can be managed by owners or platform administrators.

## Brands + Admin Import Center

Run `upgrade-brands-imports.php` once as an administrator after deploying this version. The upgrade adds brand profiles, brand memberships and approvals, CSV/TSV import batches, row-level import reports, duplicate skip/update behavior, and draft-by-default imports.

Company imports accept: `name`, `short_description`, `description`, `website`, `public_email`, `location`, `category`, `founded_year`.

Brand imports accept the same descriptive fields plus `company_name`, which must match an existing approved or draft company. Files are limited to 5,000 rows per batch. Imported records remain drafts until an administrator reviews them.


## Version 5.1.1

Fixes the Booth Management installer for MySQL servers that do not support `ALTER TABLE ... ADD COLUMN IF NOT EXISTS`. The installer now checks `information_schema` before adding each column and can be safely run again after a failed attempt.

## Version 5.2 — Developer Center

Administrators can now generate a complete connected test environment, run module diagnostics, and safely clean up records by demo batch. Install through `upgrade-developer-center.php`; see `README-v5.2.md`.
